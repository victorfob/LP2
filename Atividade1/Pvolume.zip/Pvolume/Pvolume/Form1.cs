﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        private double raio, altura, volume;

        public Form1()
        {
            InitializeComponent();
        }

        private void showError(string message)
        {
            MessageBox.Show(message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (txtRaio.Text == "") return;
            if (!Double.TryParse(txtRaio.Text, out raio))
            {
                showError("O valor do raio deve ser um número.");
                return;
            }
            if (raio <= 0)
            {
                showError("O valor do raio deve ser maior que zero.");
            }

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (txtRaio.Text == "") return;

            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                showError("O valor da altura deve ser um número.");
                return;
            }
            if (altura <= 0)
            {
                showError("O valor da altura deve ser maior que zero.");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (raio <= 0)
            {
                showError("O valor do raio deve ser um número maior que zero.");
                txtRaio.Focus();
                return;
            }

            if (altura <= 0)
            {
                showError("O valor da altura deve ser um número maior que zero.");
                txtAltura.Focus();
                return;
            }

            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtVolume.Text = volume.ToString("N2");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Clear();
            txtAltura.Clear();
            txtVolume.Clear();

            txtRaio.Focus();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
