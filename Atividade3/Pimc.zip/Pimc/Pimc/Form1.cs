﻿using System;
using System.Windows.Forms;

namespace Pimc
{
    public partial class frmImc : Form
    {
        private double peso, altura, imc;

        public frmImc()
        {
            InitializeComponent();
        }

        private void showError(string message)
        {
            MessageBox.Show(message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool isValidNumber(string text)
        {
            if (string.IsNullOrEmpty(text))
                return false;

            if (!Double.TryParse(text, out double parsedNumber))
                return false;

            return parsedNumber > 0;
        }

        private bool isValidFields()
        {
            if (!isValidNumber(mskbxPeso.Text))
            {
                showError("Peso inválido.");
                mskbxPeso.Focus();
                return false;
            }
            if (!isValidNumber(mskbxAltura.Text))
            {
                showError("Altura inválida.");
                mskbxAltura.Focus();
                return false;
            }
            return true;
        }

        private void showClassification(double parsedImc)
        {
            if (parsedImc < 18.5)
            {
                txtImc.Text = "Magreza - Obesidade grau 0";
                return;
            }
            if (parsedImc < 25)
            {
                txtImc.Text = "Normal - Obesidade grau 0";
                return;
            }
            if (parsedImc < 30)
            {
                txtImc.Text = "Sobrepeso - Obesidade grau 1";
                return;
            }
            if (parsedImc < 40)
            {
                txtImc.Text = "Obesidade - grau 2";
                return;
            }

            txtImc.Text = "Obesidade grave - grau 3";

        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (mskbxPeso.Text == "   ,") return;
            if (!Double.TryParse(mskbxPeso.Text, out peso))
                showError("Peso inválido.");
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (mskbxAltura.Text == " ,") return;
            if (!Double.TryParse(mskbxAltura.Text, out altura))
                showError("Altura inválida.");
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!isValidFields()) return;

            imc = peso / (altura * altura);

            showClassification(imc * 100);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtImc.Clear();

            mskbxPeso.Focus();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
