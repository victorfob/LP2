﻿using System;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio4 : Form
    {
        private frmPrincipal main = new frmPrincipal();

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContarNumeros_Click(object sender, EventArgs e)
        {
            string texto = txtTexto.Text;
            int i = 0;
            int qtdNumeros = 0;

            while (i < texto.Length)
            {
                if (char.IsNumber(texto[i]))
                {
                    qtdNumeros++;
                }
                i++;
            }

            if (qtdNumeros == 0)
            {
                main.showMessage("A frase não possui números");
                return;
            }

            if (qtdNumeros == 1)
            {
                main.showMessage("A frase possui 1 número");
                return;
            }

            main.showMessage($"A frase possui {qtdNumeros} números");
        }

        private void btnEncontrarEspaco_Click(object sender, EventArgs e)
        {
            string texto = txtTexto.Text;
            int posicao = 0;
            bool temEspaco = false;

            for (int i = 0; i < texto.Length; i++)
            {
                if (char.IsWhiteSpace(texto[i]))
                {
                    posicao = i;
                    temEspaco = true;
                    break;
                }
            }
            if (temEspaco)
            {
                main.showMessage($"O primeiro espaço em branco está na {posicao + 1}ª posição");
                return;
            }

            main.showMessage("Não há espaços em branco na frase");
        }


        private void btnContarLetras_Click(object sender, EventArgs e)
        {
            string texto = txtTexto.Text;
            int qtdLetras = 0;

            foreach (char c in texto)
                if (char.IsLetter(c)) qtdLetras++;

            if (qtdLetras == 0)
            {
                main.showMessage("A frase não possui letras");
                return;
            }

            if (qtdLetras == 1)
            {
                main.showMessage("A frase possui 1 letra");
                return;
            }

            main.showMessage($"A frase possui {qtdLetras} letras");
        }
    }
}
