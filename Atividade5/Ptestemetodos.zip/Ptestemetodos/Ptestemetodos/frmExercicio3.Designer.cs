﻿namespace Ptestemetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRemoverPalavra = new System.Windows.Forms.Button();
            this.lblTexto2 = new System.Windows.Forms.Label();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.lblTexto1 = new System.Windows.Forms.Label();
            this.btnReverter = new System.Windows.Forms.Button();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnRemoverPalavra
            // 
            this.btnRemoverPalavra.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRemoverPalavra.Location = new System.Drawing.Point(53, 219);
            this.btnRemoverPalavra.Margin = new System.Windows.Forms.Padding(4);
            this.btnRemoverPalavra.Name = "btnRemoverPalavra";
            this.btnRemoverPalavra.Size = new System.Drawing.Size(250, 100);
            this.btnRemoverPalavra.TabIndex = 3;
            this.btnRemoverPalavra.Text = "Remover palavra 1 da palavra 2";
            this.btnRemoverPalavra.UseVisualStyleBackColor = true;
            this.btnRemoverPalavra.Click += new System.EventHandler(this.btnRemoverPalavra_Click);
            // 
            // lblTexto2
            // 
            this.lblTexto2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTexto2.AutoSize = true;
            this.lblTexto2.Location = new System.Drawing.Point(49, 108);
            this.lblTexto2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTexto2.Name = "lblTexto2";
            this.lblTexto2.Size = new System.Drawing.Size(105, 23);
            this.lblTexto2.TabIndex = 11;
            this.lblTexto2.Text = "Palavra 2: ";
            this.lblTexto2.Click += new System.EventHandler(this.lblTexto2_Click);
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPalavra2.Location = new System.Drawing.Point(162, 104);
            this.txtPalavra2.Margin = new System.Windows.Forms.Padding(4);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(572, 30);
            this.txtPalavra2.TabIndex = 2;
            this.txtPalavra2.TextChanged += new System.EventHandler(this.txtPalavra2_TextChanged);
            // 
            // lblTexto1
            // 
            this.lblTexto1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTexto1.AutoSize = true;
            this.lblTexto1.Location = new System.Drawing.Point(49, 37);
            this.lblTexto1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTexto1.Name = "lblTexto1";
            this.lblTexto1.Size = new System.Drawing.Size(105, 23);
            this.lblTexto1.TabIndex = 8;
            this.lblTexto1.Text = "Palavra 1: ";
            this.lblTexto1.Click += new System.EventHandler(this.lblTexto1_Click);
            // 
            // btnReverter
            // 
            this.btnReverter.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnReverter.Location = new System.Drawing.Point(484, 219);
            this.btnReverter.Margin = new System.Windows.Forms.Padding(4);
            this.btnReverter.Name = "btnReverter";
            this.btnReverter.Size = new System.Drawing.Size(250, 100);
            this.btnReverter.TabIndex = 4;
            this.btnReverter.Text = "Reverter palavra 1";
            this.btnReverter.UseVisualStyleBackColor = true;
            this.btnReverter.Click += new System.EventHandler(this.btnReverter_Click);
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPalavra1.Location = new System.Drawing.Point(162, 33);
            this.txtPalavra1.Margin = new System.Windows.Forms.Padding(4);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(572, 30);
            this.txtPalavra1.TabIndex = 1;
            this.txtPalavra1.TextChanged += new System.EventHandler(this.txtPalavra1_TextChanged);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(782, 353);
            this.Controls.Add(this.btnRemoverPalavra);
            this.Controls.Add(this.lblTexto2);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.lblTexto1);
            this.Controls.Add(this.btnReverter);
            this.Controls.Add(this.txtPalavra1);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio3";
            this.Text = "Exercício 3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRemoverPalavra;
        private System.Windows.Forms.Label lblTexto2;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Label lblTexto1;
        private System.Windows.Forms.Button btnReverter;
        private System.Windows.Forms.TextBox txtPalavra1;
    }
}