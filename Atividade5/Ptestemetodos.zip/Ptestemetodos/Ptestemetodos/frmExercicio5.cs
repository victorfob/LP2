﻿using System;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio5: Form
    {
        private frmPrincipal main = new frmPrincipal();
        private double numero1, numero2;

        public frmExercicio5()
        {
            InitializeComponent();
        }

        private bool checarNumeros()
        {
            try
            {
                numero1 = Convert.ToDouble(txtNumero1.Text);
                numero2 = Convert.ToDouble(txtNumero2.Text);
            }
            catch (FormatException)
            {
                main.showError("Os números devem ser válidos");
                return false;
            }

            if(numero1 >numero2 )
            {
                main.showError("O primeiro número deve ser menor que o segundo");
                return false;
            }

            return true;
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (!checarNumeros()) return;

            Random random = new Random();
            int numeroSorteado = random.Next((int)numero1, (int)numero2 + 1);

            main.showMessage($"O número sorteado foi: {numeroSorteado}");
        }
    }
}
