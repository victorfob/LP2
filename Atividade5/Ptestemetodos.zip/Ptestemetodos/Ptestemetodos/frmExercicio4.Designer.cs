﻿namespace Ptestemetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTexto = new System.Windows.Forms.RichTextBox();
            this.btnContarNumeros = new System.Windows.Forms.Button();
            this.btnEncontrarEspaco = new System.Windows.Forms.Button();
            this.btnContarLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtTexto
            // 
            this.txtTexto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTexto.Location = new System.Drawing.Point(30, 38);
            this.txtTexto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(722, 188);
            this.txtTexto.TabIndex = 0;
            this.txtTexto.Text = "";
            // 
            // btnContarNumeros
            // 
            this.btnContarNumeros.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnContarNumeros.Location = new System.Drawing.Point(30, 254);
            this.btnContarNumeros.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnContarNumeros.Name = "btnContarNumeros";
            this.btnContarNumeros.Size = new System.Drawing.Size(190, 60);
            this.btnContarNumeros.TabIndex = 4;
            this.btnContarNumeros.Text = "Contar números";
            this.btnContarNumeros.UseVisualStyleBackColor = true;
            this.btnContarNumeros.Click += new System.EventHandler(this.btnContarNumeros_Click);
            // 
            // btnEncontrarEspaco
            // 
            this.btnEncontrarEspaco.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnEncontrarEspaco.Location = new System.Drawing.Point(266, 254);
            this.btnEncontrarEspaco.Margin = new System.Windows.Forms.Padding(6);
            this.btnEncontrarEspaco.Name = "btnEncontrarEspaco";
            this.btnEncontrarEspaco.Size = new System.Drawing.Size(220, 60);
            this.btnEncontrarEspaco.TabIndex = 5;
            this.btnEncontrarEspaco.Text = "Encontrar 1º espaço";
            this.btnEncontrarEspaco.UseVisualStyleBackColor = true;
            this.btnEncontrarEspaco.Click += new System.EventHandler(this.btnEncontrarEspaco_Click);
            // 
            // btnContarLetras
            // 
            this.btnContarLetras.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnContarLetras.Location = new System.Drawing.Point(532, 254);
            this.btnContarLetras.Margin = new System.Windows.Forms.Padding(6);
            this.btnContarLetras.Name = "btnContarLetras";
            this.btnContarLetras.Size = new System.Drawing.Size(220, 60);
            this.btnContarLetras.TabIndex = 6;
            this.btnContarLetras.Text = "Contar letras";
            this.btnContarLetras.UseVisualStyleBackColor = true;
            this.btnContarLetras.Click += new System.EventHandler(this.btnContarLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(782, 353);
            this.Controls.Add(this.btnContarLetras);
            this.Controls.Add(this.btnEncontrarEspaco);
            this.Controls.Add(this.btnContarNumeros);
            this.Controls.Add(this.txtTexto);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmExercicio4";
            this.Text = "Exercício 4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtTexto;
        private System.Windows.Forms.Button btnContarNumeros;
        private System.Windows.Forms.Button btnEncontrarEspaco;
        private System.Windows.Forms.Button btnContarLetras;
    }
}