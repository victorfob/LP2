﻿namespace Ptestemetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.btnComparar = new System.Windows.Forms.Button();
            this.lblTexto1 = new System.Windows.Forms.Label();
            this.lblTexto2 = new System.Windows.Forms.Label();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btnInserirPalavra = new System.Windows.Forms.Button();
            this.btnInserirAsteriscos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPalavra1.Location = new System.Drawing.Point(162, 49);
            this.txtPalavra1.Margin = new System.Windows.Forms.Padding(4);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(572, 30);
            this.txtPalavra1.TabIndex = 1;
            // 
            // btnComparar
            // 
            this.btnComparar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnComparar.Location = new System.Drawing.Point(53, 234);
            this.btnComparar.Margin = new System.Windows.Forms.Padding(4);
            this.btnComparar.Name = "btnComparar";
            this.btnComparar.Size = new System.Drawing.Size(160, 70);
            this.btnComparar.TabIndex = 3;
            this.btnComparar.Text = "Comparar";
            this.btnComparar.UseVisualStyleBackColor = true;
            this.btnComparar.Click += new System.EventHandler(this.btnComparar_Click);
            // 
            // lblTexto1
            // 
            this.lblTexto1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTexto1.AutoSize = true;
            this.lblTexto1.Location = new System.Drawing.Point(49, 53);
            this.lblTexto1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTexto1.Name = "lblTexto1";
            this.lblTexto1.Size = new System.Drawing.Size(105, 23);
            this.lblTexto1.TabIndex = 2;
            this.lblTexto1.Text = "Palavra 1: ";
            // 
            // lblTexto2
            // 
            this.lblTexto2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTexto2.AutoSize = true;
            this.lblTexto2.Location = new System.Drawing.Point(49, 124);
            this.lblTexto2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTexto2.Name = "lblTexto2";
            this.lblTexto2.Size = new System.Drawing.Size(105, 23);
            this.lblTexto2.TabIndex = 4;
            this.lblTexto2.Text = "Palavra 2: ";
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPalavra2.Location = new System.Drawing.Point(162, 120);
            this.txtPalavra2.Margin = new System.Windows.Forms.Padding(4);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(572, 30);
            this.txtPalavra2.TabIndex = 2;
            // 
            // btnInserirPalavra
            // 
            this.btnInserirPalavra.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnInserirPalavra.Location = new System.Drawing.Point(313, 234);
            this.btnInserirPalavra.Margin = new System.Windows.Forms.Padding(4);
            this.btnInserirPalavra.Name = "btnInserirPalavra";
            this.btnInserirPalavra.Size = new System.Drawing.Size(160, 70);
            this.btnInserirPalavra.TabIndex = 4;
            this.btnInserirPalavra.Text = "Inserir palavra 1 na palavra 2";
            this.btnInserirPalavra.UseVisualStyleBackColor = true;
            this.btnInserirPalavra.Click += new System.EventHandler(this.btnInserirPalavra_Click);
            // 
            // btnInserirAsteriscos
            // 
            this.btnInserirAsteriscos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnInserirAsteriscos.Location = new System.Drawing.Point(573, 234);
            this.btnInserirAsteriscos.Margin = new System.Windows.Forms.Padding(4);
            this.btnInserirAsteriscos.Name = "btnInserirAsteriscos";
            this.btnInserirAsteriscos.Size = new System.Drawing.Size(160, 70);
            this.btnInserirAsteriscos.TabIndex = 5;
            this.btnInserirAsteriscos.Text = "Inserir ** na palavra 1";
            this.btnInserirAsteriscos.UseVisualStyleBackColor = true;
            this.btnInserirAsteriscos.Click += new System.EventHandler(this.btnInserirAsteriscos_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(782, 353);
            this.Controls.Add(this.btnInserirAsteriscos);
            this.Controls.Add(this.btnInserirPalavra);
            this.Controls.Add(this.lblTexto2);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.lblTexto1);
            this.Controls.Add(this.btnComparar);
            this.Controls.Add(this.txtPalavra1);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio2";
            this.Text = "Exercício 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.Button btnComparar;
        private System.Windows.Forms.Label lblTexto1;
        private System.Windows.Forms.Label lblTexto2;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btnInserirPalavra;
        private System.Windows.Forms.Button btnInserirAsteriscos;
    }
}