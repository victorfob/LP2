﻿using System;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio2 : Form
    {
        private frmPrincipal main = new frmPrincipal();
        private string palavra1, palavra2;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private bool checarPalavras(bool checarTodas = true)
        {
            palavra1 = txtPalavra1.Text;
            palavra2 = txtPalavra2.Text;

            if (String.IsNullOrEmpty(palavra1))
            {
                main.showError("A palavra 1 não pode ser vazia");
                return false;
            }

            if (checarTodas && String.IsNullOrEmpty(palavra2))
            {
                main.showError("A palavra 2 não pode ser vazia");
                return false;
            }

            return true;
        }


        private void btnComparar_Click(object sender, EventArgs e)
        {
            if (!checarPalavras()) return;

            int result = String.Compare(palavra1, palavra2);

            if (result == 0)
            {
                main.showMessage("As palavras são iguais");
                return;
            }

            main.showMessage("As palavras são diferentes");
        }


        private void btnInserirPalavra_Click(object sender, EventArgs e)
        {
            if (!checarPalavras()) return;

            int meio = palavra2.Length / 2;
            string novaPalavra = palavra2.Substring(0, meio) + palavra1 + palavra2.Substring(meio);

            palavra2 = novaPalavra;
            txtPalavra2.Text = novaPalavra;
        }

        private void btnInserirAsteriscos_Click(object sender, EventArgs e)
        {
            if (!checarPalavras(false)) return;

            int meio = palavra1.Length / 2;
            string novaPalavra = palavra1.Insert(meio, "**");

            palavra2 = novaPalavra;
            txtPalavra2.Text = novaPalavra;
        }
    }
}
