﻿using System;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio3 : Form
    {
        private frmPrincipal main = new frmPrincipal();
        private string palavra1, palavra2;

        public frmExercicio3()
        {
            InitializeComponent();
        }

        private bool checarPalavras(bool checarTodas = true)
        {
            palavra1 = txtPalavra1.Text;
            palavra2 = txtPalavra2.Text;

            if (String.IsNullOrEmpty(palavra1))
            {
                main.showError("A palavra 1 não pode ser vazia");
                return false;
            }

            if (checarTodas && String.IsNullOrEmpty(palavra2))
            {
                main.showError("A palavra 2 não pode ser vazia");
                return false;
            }

            return true;
        }

        private void btnRemoverPalavra_Click(object sender, EventArgs e)
        {
            if (!checarPalavras()) return;

            string novaPalavra = palavra2.Replace(palavra1, "");

            palavra2 = novaPalavra;
            txtPalavra2.Text = novaPalavra;
        }

        private void txtPalavra2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblTexto2_Click(object sender, EventArgs e)
        {

        }

        private void txtPalavra1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblTexto1_Click(object sender, EventArgs e)
        {

        }

        private void btnReverter_Click(object sender, EventArgs e)
        {
            if (!checarPalavras(false)) return;

            char[] arr = palavra1.ToCharArray();
            Array.Reverse(arr);
            string novaPalavra = new string(arr);

            palavra1 = novaPalavra;
            txtPalavra1.Text = novaPalavra;
        }
    }
}
