﻿namespace Ploops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnContarPares = new System.Windows.Forms.Button();
            this.btnContarLetraR = new System.Windows.Forms.Button();
            this.btnContarEspacos = new System.Windows.Forms.Button();
            this.txtTexto = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnContarPares
            // 
            this.btnContarPares.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnContarPares.Location = new System.Drawing.Point(532, 254);
            this.btnContarPares.Margin = new System.Windows.Forms.Padding(6);
            this.btnContarPares.Name = "btnContarPares";
            this.btnContarPares.Size = new System.Drawing.Size(220, 60);
            this.btnContarPares.TabIndex = 10;
            this.btnContarPares.Text = "Contar pares";
            this.btnContarPares.UseVisualStyleBackColor = true;
            this.btnContarPares.Click += new System.EventHandler(this.btnContarPares_Click);
            // 
            // btnContarLetraR
            // 
            this.btnContarLetraR.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnContarLetraR.Location = new System.Drawing.Point(266, 254);
            this.btnContarLetraR.Margin = new System.Windows.Forms.Padding(6);
            this.btnContarLetraR.Name = "btnContarLetraR";
            this.btnContarLetraR.Size = new System.Drawing.Size(220, 60);
            this.btnContarLetraR.TabIndex = 9;
            this.btnContarLetraR.Text = "Contar letra R";
            this.btnContarLetraR.UseVisualStyleBackColor = true;
            this.btnContarLetraR.Click += new System.EventHandler(this.btnContarLetraR_Click);
            // 
            // btnContarEspacos
            // 
            this.btnContarEspacos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnContarEspacos.Location = new System.Drawing.Point(30, 254);
            this.btnContarEspacos.Margin = new System.Windows.Forms.Padding(6);
            this.btnContarEspacos.Name = "btnContarEspacos";
            this.btnContarEspacos.Size = new System.Drawing.Size(190, 60);
            this.btnContarEspacos.TabIndex = 8;
            this.btnContarEspacos.Text = "Contar espaços";
            this.btnContarEspacos.UseVisualStyleBackColor = true;
            this.btnContarEspacos.Click += new System.EventHandler(this.btnContarEspacos_Click);
            // 
            // txtTexto
            // 
            this.txtTexto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTexto.Location = new System.Drawing.Point(30, 38);
            this.txtTexto.Margin = new System.Windows.Forms.Padding(4);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(722, 188);
            this.txtTexto.TabIndex = 7;
            this.txtTexto.Text = "";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(782, 353);
            this.Controls.Add(this.btnContarPares);
            this.Controls.Add(this.btnContarLetraR);
            this.Controls.Add(this.btnContarEspacos);
            this.Controls.Add(this.txtTexto);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio1";
            this.Text = "Exercício 1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnContarPares;
        private System.Windows.Forms.Button btnContarLetraR;
        private System.Windows.Forms.Button btnContarEspacos;
        private System.Windows.Forms.RichTextBox txtTexto;
    }
}