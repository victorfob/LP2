﻿using System;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio4 : Form
    {
        private FrmInicio main = new FrmInicio();
        private string nome;
        private int matricula, producao = 0;
        private double salario = 0, gratificacao = 0;

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNome.Text))
            {
                main.showError("O campo nome não pode ser vazio.");
                return;
            }

            nome = txtNome.Text;
        }

        private void txtMatricula_Validated(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMatricula.Text))
            {
                main.showError("O campo matrícula não pode ser vazio.");
                return;
            }

            if (Int32.TryParse(txtMatricula.Text, out matricula))
            {
                if (matricula < 0)
                {
                    main.showError("O campo matrícula não pode ser negativo.");
                }
                return;
            }

            main.showError("O campo matrícula deve ser um número inteiro.");
        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtProducao.Text))
            {
                main.showError("O campo produção não pode ser vazio.");
                return;
            }

            if (Int32.TryParse(txtProducao.Text, out producao))
            {
                if (producao < 0)
                {
                    main.showError("O campo produção não pode ser negativo.");
                }
                return;
            }

            main.showError("O campo produção deve ser um número inteiro.");
        }

        private void txtSalario_Validated(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSalario.Text))
            {
                main.showError("O campo salário não pode ser vazio.");
                return;
            }

            if (Double.TryParse(txtSalario.Text, out salario))
            {
                if (salario < 0)
                {
                    main.showError("O campo salário não pode ser negativo.");
                }
                return;
            }

            main.showError("O campo salário deve ser um número decimal.");
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtGratificacao.Text))
            {
                main.showError("O campo gratificação não pode ser vazio.");
                return;
            }

            if (Double.TryParse(txtGratificacao.Text, out gratificacao))
            {
                if (gratificacao < 0)
                {
                    main.showError("O campo gratificação não pode ser negativo.");
                }
                return;
            }

            main.showError("O campo gratificação deve ser um número decimal.");
        }
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Salario bruto = A + A *(0,05 * B + 0,1 * C + 0,1 * D) + gratificacao

            double A = salario;
            int B = (producao >= 100) ? 1 : 0;
            int C = (producao >= 120) ? 1 : 0;
            int D = (producao >= 150) ? 1 : 0;
            double salarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

            if (salarioBruto > 7000 && (D == 0 || gratificacao <= 0))
                salarioBruto = 7000.0;

            string message = $"Nome: {nome}\n" +
                             $"Matrícula: {matricula}\n" +
                             $"Produção: {producao}\n" +
                             $"Salário: {salario}\n" +
                             $"Gratificação: {gratificacao}\n" +
                             $"Salário Bruto: R$ {salarioBruto:N2}";

            main.showMessage(message);
        }
    }
}
