﻿using System;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio2 : Form
    {
        private FrmInicio main = new FrmInicio();
        private int numero = 1;

        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtNumero_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero.Text, out numero) || numero <= 0)
            {
                main.showError("O número deve ser um inteiro válido e maior que zero");
                txtNumero.Focus();
                return;
            }
        }

        private void btnCalcularH_Click(object sender, EventArgs e)
        {
            double h = 1;

            for (int i = 2; i <= numero; i++)
                h += (1.0 / i);

            main.showMessage($"O valor de H é: {h:N3}");
        }
    }
}
