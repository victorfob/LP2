﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio1 : Form
    {
        private FrmInicio main = new FrmInicio();
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnContarEspacos_Click(object sender, EventArgs e)
        {
            string texto = txtTexto.Text;
            int qtdEspacos = 0;


            foreach (char c in texto)
                if (char.IsWhiteSpace(c)) qtdEspacos++;

            if (qtdEspacos > 1)
            {
                main.showMessage($"Foram encontrados {qtdEspacos} espaços");
                return;
            }

            if (qtdEspacos == 1)
            {
                main.showMessage("Foi encontrado um espaço");
                return;
            }

            main.showMessage("Não há espaços em branco na frase");
        }

        private void btnContarLetraR_Click(object sender, EventArgs e)
        {
            string texto = txtTexto.Text.ToUpper();
            int i = 0;
            int qtdRs = 0;

            while (i < texto.Length)
            {
                if (texto[i] == 'R')
                    qtdRs++;

                i++;
            }

            if (qtdRs == 0)
            {
                main.showMessage("A frase não possui letras R");
                return;
            }

            if (qtdRs == 1)
            {
                main.showMessage("A frase possui uma letra R");
                return;
            }

            main.showMessage($"A frase possui {qtdRs} letras R");
        }

        private void btnContarPares_Click(object sender, EventArgs e)
        {
            string texto = txtTexto.Text.ToUpper();
            int qtdPares = 0;

            for (int i = 0; i < texto.Length; i++)
            {
                int nextIndex = i + 1;
                if (char.IsLetter(texto[i]) && nextIndex < texto.Length)
                {
                    if (char.IsLetter(texto[i + 1]) && texto[i] == texto[nextIndex])
                        qtdPares++;
                }
            }

            if (qtdPares == 0)
            {
                main.showMessage("A frase não possui pares de letras");
                return;
            }

            if (qtdPares == 1)
            {
                main.showMessage("A frase possui um par de letras");
                return;
            }

            main.showMessage($"A frase possui {qtdPares} pares de letras");
        }
    }
}
