﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio3 : Form
    {
        private FrmInicio main = new FrmInicio();

        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string textoOriginal = txtPalindromo.Text;
            string texto = textoOriginal.ToLower().Replace(" ", "");

            if (texto.Length > 50)
            {
                main.showError("O texto deve ter no máximo 50 caracteres.");
                return;
            }

            if (string.IsNullOrEmpty(texto))
            {
                main.showError("O texto não pode ser vazio.");
                return;
            }

            char[] textoInChar = texto.ToCharArray();
            Array.Reverse(textoInChar);
            string textoInvertido = new string(textoInChar);

            if (texto == textoInvertido)
            {
                main.showMessage($"O texto '{textoOriginal}' é um palíndromo.");
            }
            else
            {
                main.showMessage($"O texto '{textoOriginal}' não é um palíndromo.");
            }
        }
    }
}
