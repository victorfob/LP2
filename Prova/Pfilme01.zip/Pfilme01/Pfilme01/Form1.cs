﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace Pfilme01
{
    public partial class Filmes : Form
    {
        public Filmes()
        {
            InitializeComponent();
        }

        private double lerNota(int i, int j)
        {
            if (!Double.TryParse(Interaction.InputBox($"Pessoa {i + 1}, digite a nota do {j + 1}º filme: ", "Entrada de Dados", ""), out double nota) || nota < 0 || nota > 10)
            {
                MessageBox.Show("Nota inválida, digite uma nota entre 0 e 10", "Ocorreu um erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }

            return nota;
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
            double[,] notasFilmes = new double[3, 2];
            double[] medias = new double[2] { 0, 0 };

            for (int i = 0; i < notasFilmes.GetLength(0); i++)
            {
                string resultado = $"Pessoa {i + 1} - ";
                for (int j = 0; j < notasFilmes.GetLength(1); j++)
                {
                    notasFilmes[i, j] = lerNota(i, j);
                    if (notasFilmes[i, j] == -1)
                        j--;
                    else
                    {
                        resultado += $"Nota filme {j + 1}: {notasFilmes[i, j]:N2} ";
                        medias[j] += notasFilmes[i, j];
                    }
                }
                lstbxResultado.Items.Add(resultado);
            }

            lstbxResultado.Items.Add("----------------------------------------------------------------------");

            for (int i = 0; i < medias.GetLength(0); i++)
            {
                medias[i] /= notasFilmes.GetLength(0);
                lstbxResultado.Items.Add($"Média Filme {i + 1}: {medias[i]:N2}");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }
    }
}
