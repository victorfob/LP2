﻿using System;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class frmCalculadora : Form
    {
        private double numero1, numero2, resultado;

        public frmCalculadora()
        {
            InitializeComponent();
        }
        private void showError(string message)
        {
            MessageBox.Show(message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool isValidNumber(string text)
        {
            if (string.IsNullOrEmpty(text))
                return false;

            return Double.TryParse(text, out _);
        }

        private bool isValidFields()
        {
            if (!isValidNumber(txtNumero1.Text))
            {
                showError("Primeiro número inválido.");
                txtNumero1.Focus();
                return false;
            }
            if (!isValidNumber(txtNumero2.Text))
            {
                showError("Segundo número inválido.");
                txtNumero2.Focus();
                return false;
            }
            return true;
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (txtNumero1.Text == "") return;
            if (!Double.TryParse(txtNumero1.Text, out numero1))
                showError("Primeiro número inválido.");
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (txtNumero2.Text == "") return;
            if (!Double.TryParse(txtNumero2.Text, out numero2))
                showError("Segundo número inválido.");
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            if (!isValidFields()) return;

            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            if (!isValidFields()) return;

            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            if (!isValidFields()) return;

            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            if (!isValidFields()) return;

            if (numero2 == 0)
            {
                showError("Segundo número não pode ser zero.");
                return;
            }
            resultado = numero1 / numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnElevar_Click(object sender, EventArgs e)
        {
            if (!isValidFields()) return;

            resultado = Math.Pow(numero1, numero2);
            txtResultado.Text = resultado.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();

            txtNumero1.Focus();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
