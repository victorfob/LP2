﻿using System;
using System.Data;
using System.Windows.Forms;

namespace PFerramenta0030482423040
{
    public partial class frmFerramenta : Form
    {
        private BindingSource bnFerramenta = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFerramenta = new DataSet();
        private DataSet dsCategoria = new DataSet();
        private DataSet dsFabricante = new DataSet();
        private frmPrincipal frmPrincipal = new frmPrincipal();

        public frmFerramenta()
        {
            InitializeComponent();
        }

        private void openDetailsTab()
        {
            if (tbFerramenta.SelectedIndex == 0)
                tbFerramenta.SelectTab(1);
        }

        private void enableFieldsAndDisableActions(bool ehInclusao)
        {
            txtNome.Enabled = true;
            txtNome.Focus();
            txtSite.Enabled = true;

            dtpCadastro.Enabled = true;

            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;
            cbxDistribuicao.Enabled = true;
            cbxCategoria.SelectedIndex = 0;
            cbxFabricante.SelectedIndex = 0;
            cbxDistribuicao.SelectedIndex = 0;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = ehInclusao;

            if (ehInclusao)
                txtId.Clear();
        }

        private void disableFieldsAndEnableActions()
        {
            txtNome.Enabled = false;
            txtSite.Enabled = false;
            dtpCadastro.Enabled = false;
            cbxCategoria.Enabled = false;
            cbxFabricante.Enabled = false;
            cbxDistribuicao.Enabled = false;

            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovoRegistro.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            bInclusao = false;
        }

        private void reloadGrid()
        {
            Ferramenta R = new Ferramenta();
            dsFerramenta.Tables.Clear();
            dsFerramenta.Tables.Add(R.Listar());
            bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
            tbFerramenta.SelectTab(0);
        }

        private bool isValidFields()
        {
            string nome = txtNome.Text.Trim();
            string nomeSemEspacos = nome.Replace(" ", "");

            if (nome.Length == 0 || nomeSemEspacos.Length < 1)
            {
                frmPrincipal.showError("Nome inválido!");
                txtNome.Focus();
                return false;
            }

            if (cbxDistribuicao.SelectedIndex == -1)
            {
                frmPrincipal.showError("Selecione uma distribuição!");
                cbxDistribuicao.Focus();
                return false;
            }

            string site = txtSite.Text.Trim();
            string siteSemEspacos = site.Replace(" ", "");

            if (site.Length == 0 || siteSemEspacos.Length < 8)
            {
                frmPrincipal.showError("Site oficial inválido!");
                txtSite.Focus();
                return false;
            }

            if (Convert.ToDateTime(dtpCadastro.Value) < DateTime.Today)
            {
                frmPrincipal.showError("Data de cadastro inválida!");
                dtpCadastro.Focus();
                return false;
            }

            if (cbxCategoria.SelectedIndex == -1)
            {
                frmPrincipal.showError("Selecione uma categoria!");
                cbxCategoria.Focus();
                return false;
            }

            if (cbxFabricante.SelectedIndex == -1)
            {
                frmPrincipal.showError("Selecione um fabricante!");
                cbxFabricante.Focus();
                return false;
            }

            return true;
        }

        private void frmFerramenta_Load(object sender, EventArgs e)
        {
            try
            {
                Ferramenta RegFer = new Ferramenta();
                dsFerramenta.Tables.Add(RegFer.Listar());
                bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                dgvFerramenta.DataSource = bnFerramenta;
                bnvFerramenta.BindingSource = bnFerramenta;

                txtId.DataBindings.Add("Text", bnFerramenta, "id");
                txtNome.DataBindings.Add("Text", bnFerramenta, "nome");
                cbxDistribuicao.DataBindings.Add("SelectedItem", bnFerramenta, "distribuicao");
                dtpCadastro.DataBindings.Add("Text", bnFerramenta, "dtCadastro");
                txtSite.DataBindings.Add("Text", bnFerramenta, "siteOficial");

                // Carregar categorias e fabricantes

                Categoria RegCat = new Categoria();
                dsCategoria.Tables.Add(RegCat.Listar());
                cbxCategoria.DataSource = dsCategoria.Tables["CATEGORIA"];
                cbxCategoria.DisplayMember = "descricao";
                cbxCategoria.ValueMember = "id";
                cbxCategoria.DataBindings.Add("SelectedValue", bnFerramenta, "idCategoria");

                Fabricante RegFab = new Fabricante();
                dsFabricante.Tables.Add(RegFab.Listar());
                cbxFabricante.DataSource = dsFabricante.Tables["FABRICANTE"];
                cbxFabricante.DisplayMember = "nomeFantasia";
                cbxFabricante.ValueMember = "id";
                cbxFabricante.DataBindings.Add("SelectedValue", bnFerramenta, "idFabricante");
            }
            catch (Exception ex)
            {
                frmPrincipal.showError($"Erro ao carregar as ferramentas: {ex.Message}");
            }
        }

        private void tbFerramenta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter && isValidFields())
                btnSalvar_Click(sender, e);
        }

        private void tbFerramenta_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
                btnCancelar_Click(sender, e);
        }

        private void dgvFerramenta_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                btnExcluir_Click(sender, e);
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            openDetailsTab();
            bnFerramenta.AddNew();
            enableFieldsAndDisableActions(true);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (!isValidFields())
                return;

            Ferramenta RegFer = new Ferramenta();
            RegFer.Nome = txtNome.Text.Trim();
            RegFer.Distribuicao = Convert.ToChar(cbxDistribuicao.SelectedItem);
            RegFer.DtCadastro = dtpCadastro.Value;
            RegFer.SiteOficial = txtSite.Text.Trim();
            RegFer.IdCategoria = Convert.ToInt16(cbxCategoria.SelectedValue.ToString());
            RegFer.IdFabricante = Convert.ToInt16(cbxFabricante.SelectedValue.ToString());

            if (bInclusao)
            {
                if (RegFer.Salvar() > 0)
                {
                    frmPrincipal.showSuccess("Ferramenta adicionada com sucesso!");

                    disableFieldsAndEnableActions();
                    reloadGrid();
                    return;
                }

                frmPrincipal.showError("Erro ao adicionar ferramenta. Verifique os dados e tente novamente.");
                return;
            }

            RegFer.IdFerramenta = Convert.ToInt16(txtId.Text);

            if (RegFer.Alterar() > 0)
            {
                frmPrincipal.showSuccess("Ferramenta alterada com sucesso!");

                disableFieldsAndEnableActions();
                reloadGrid();
                return;
            }

            frmPrincipal.showError("Erro ao alterar ferramenta. Verifique os dados e tente novamente.");
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            openDetailsTab();
            enableFieldsAndDisableActions(false);
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            openDetailsTab();

            if (MessageBox.Show("Confirma exclusão?", "Yer or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Ferramenta RegFer = new Ferramenta();
                RegFer.IdFerramenta = Convert.ToInt16(txtId.Text);

                if (RegFer.Excluir() > 0)
                {
                    frmPrincipal.showSuccess("Ferramenta excluída com sucesso!");
                    reloadGrid();
                    return;
                }

                frmPrincipal.showError("Erro ao excluir ferramenta!");
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnFerramenta.CancelEdit();
            disableFieldsAndEnableActions();
            tbFerramenta.SelectTab(0);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
