﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PFerramenta0030482423040
{
    public partial class frmCategoria : Form
    {
        private BindingSource bnCategoria = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsCategoria = new DataSet();
        private frmPrincipal frmPrincipal = new frmPrincipal();

        public frmCategoria()
        {
            InitializeComponent();
        }
        private void openDetailsTab()
        {
            if (tbCategoria.SelectedIndex == 0)
                tbCategoria.SelectTab(1);
        }

        private void enableFieldsAndDisableActions(bool ehInclusao)
        {
            txtDescricao.Enabled = true;
            txtDescricao.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = ehInclusao;

            if (ehInclusao)
                txtId.Clear();
        }

        private void disableFieldsAndEnableActions()
        {
            txtDescricao.Enabled = false;
            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovoRegistro.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            bInclusao = false;
        }

        private void reloadGrid()
        {
            Categoria R = new Categoria();
            dsCategoria.Tables.Clear();
            dsCategoria.Tables.Add(R.Listar());
            bnCategoria.DataSource = dsCategoria.Tables["CATEGORIA"];
            tbCategoria.SelectTab(0);
        }

        private bool isValidField()
        {
            string descricao = txtDescricao.Text.Trim();
            string descricaoSemEspacos = descricao.Replace(" ", "");

            if (descricao.Length == 0 || descricaoSemEspacos.Length < 5)
            {
                frmPrincipal.showError("Categoria inválida");
                return false;
            }

            return true;
        }

        private void frmCategoria_Load(object sender, EventArgs e)
        {
            try
            {
                Categoria RegCat = new Categoria();
                dsCategoria.Tables.Add(RegCat.Listar());
                bnCategoria.DataSource = dsCategoria.Tables["CATEGORIA"];
                dgvCategoria.DataSource = bnCategoria;
                bnvCategoria.BindingSource = bnCategoria;

                txtId.DataBindings.Add("TEXT", bnCategoria, "id");
                txtDescricao.DataBindings.Add("TEXT", bnCategoria, "descricao");
            }
            catch (Exception ex)
            {
                frmPrincipal.showError($"Erro ao carregar as categorias: {ex.Message}");
            }
        }

        private void tbCategoria_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter && isValidField())
                btnSalvar_Click(sender, e);
        }

        private void tbCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tbCategoria.SelectedIndex == 0)
                btnCancelar_Click(sender, e);
        }

        private void dgvCategoria_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                btnExcluir_Click(sender, e);
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            openDetailsTab();
            bnCategoria.AddNew();
            enableFieldsAndDisableActions(true);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (!isValidField())
            {
                txtDescricao.Focus();
                return;
            }

            Categoria RegCat = new Categoria();
            RegCat.Descricao = txtDescricao.Text.Trim();

            if (bInclusao)
            {
                if (RegCat.Salvar() > 0)
                {
                    frmPrincipal.showSuccess("Categoria adicionada com sucesso!");

                    disableFieldsAndEnableActions();
                    reloadGrid();
                    return;
                }

                frmPrincipal.showError("Erro ao adicionar categoria. Verifique os dados e tente novamente.");
                return;
            }

            RegCat.IdCategoria = Convert.ToInt16(txtId.Text);

            if (RegCat.Alterar() > 0)
            {
                frmPrincipal.showSuccess("Categoria alterada com sucesso!");

                disableFieldsAndEnableActions();
                reloadGrid();
                return;
            }

            frmPrincipal.showError("Erro ao alterar categoria. Verifique os dados e tente novamente.");
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            openDetailsTab();
            enableFieldsAndDisableActions(false);
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                openDetailsTab();

                if (MessageBox.Show("Confirma exclusão?", "Yer or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    Categoria RegCat = new Categoria();
                    RegCat.IdCategoria = Convert.ToInt16(txtId.Text);

                    if (RegCat.Excluir() > 0)
                    {
                        frmPrincipal.showSuccess("Categoria excluída com sucesso!");
                        reloadGrid();
                        return;
                    }

                    frmPrincipal.showError("Erro ao excluir categoria!");
                }
            }
            catch (SqlException ex)
            {
                frmPrincipal.showError($"Esta categoria está atribuída a uma ou mais ferramentas. Delete primeiro a(s) ferramenta(s) e tente novamente.");
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnCategoria.CancelEdit();
            disableFieldsAndEnableActions();
            tbCategoria.SelectTab(0);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
