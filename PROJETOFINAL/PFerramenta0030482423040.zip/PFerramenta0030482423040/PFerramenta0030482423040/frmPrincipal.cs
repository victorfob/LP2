﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace PFerramenta0030482423040
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        public void showError(string message)
        {
            MessageBox.Show(message, "Ocorreu um erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public void showSuccess(string message)
        {
            MessageBox.Show(message, "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=localhost;Initial Catalog=LP2;Integrated Security=True;TrustServerCertificate=True;");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                showError($"Erro ao conectar ao banco de dados: {ex.Message}");
            }
            catch (Exception ex)
            {
                showError($"Erro inesperado: {ex.Message}");
            }
        }

        private void categoriasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCategoria>().Count() > 0)
            {
                Application.OpenForms["frmCategoria"].BringToFront();
                return;
            }

            frmCategoria form = new frmCategoria();
            form.MdiParent = this;
            form.WindowState = FormWindowState.Maximized;
            form.Show();
        }

        private void fabricantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmFabricante>().Count() > 0)
            {
                Application.OpenForms["frmFabricante"].BringToFront();
                return;
            }

            frmFabricante form = new frmFabricante();
            form.MdiParent = this;
            form.WindowState = FormWindowState.Maximized;
            form.Show();
        }

        private void ferramentasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmFerramenta>().Count() > 0)
            {
                Application.OpenForms["frmFerramenta"].BringToFront();
                return;
            }

            frmFerramenta form = new frmFerramenta();
            form.MdiParent = this;
            form.WindowState = FormWindowState.Maximized;
            form.Show();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
                return;
            }

            frmSobre form = new frmSobre();
            form.MdiParent = this;
            form.WindowState = FormWindowState.Maximized;
            form.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
