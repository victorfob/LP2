﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PFerramenta0030482423040
{
    public partial class frmFabricante : Form
    {
        private BindingSource bnFabricante = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFabricante = new DataSet();
        private frmPrincipal frmPrincipal = new frmPrincipal();

        public frmFabricante()
        {
            InitializeComponent();
        }

        private void openDetailsTab()
        {
            if (tbFabricante.SelectedIndex == 0)
                tbFabricante.SelectTab(1);
        }

        private void enableFieldsAndDisableActions(bool ehInclusao)
        {
            txtNome.Enabled = true;
            txtNome.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = ehInclusao;

            if (ehInclusao)
                txtId.Clear();
        }

        private void disableFieldsAndEnableActions()
        {
            txtNome.Enabled = false;
            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovoRegistro.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            bInclusao = false;
        }

        private void reloadGrid()
        {
            Fabricante R = new Fabricante();
            dsFabricante.Tables.Clear();
            dsFabricante.Tables.Add(R.Listar());
            bnFabricante.DataSource = dsFabricante.Tables["FABRICANTE"];
            tbFabricante.SelectTab(0);
        }

        private bool isValidField()
        {
            string descricao = txtNome.Text.Trim();
            string descricaoSemEspacos = descricao.Replace(" ", "");

            if (descricao.Length == 0 || descricaoSemEspacos.Length < 5)
            {
                frmPrincipal.showError("Fabricante inválido");
                return false;
            }

            return true;
        }

        private void frmFabricante_Load(object sender, EventArgs e)
        {
            try
            {
                Fabricante RegFab = new Fabricante();
                dsFabricante.Tables.Add(RegFab.Listar());
                bnFabricante.DataSource = dsFabricante.Tables["FABRICANTE"];
                dgvFabricante.DataSource = bnFabricante;
                bnvFabricante.BindingSource = bnFabricante;

                txtId.DataBindings.Add("TEXT", bnFabricante, "id");
                txtNome.DataBindings.Add("TEXT", bnFabricante, "nomeFantasia");
            }
            catch (Exception ex)
            {
                frmPrincipal.showError($"Erro ao carregar os fabricantes: {ex.Message}");
            }
        }

        private void tbFabricante_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter && isValidField())
                btnSalvar_Click(sender, e);
        }
        private void tbFabricante_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tbFabricante.SelectedIndex == 0)
                btnCancelar_Click(sender, e);
        }

        private void dgvFabricante_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                btnExcluir_Click(sender, e);
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            openDetailsTab();
            bnFabricante.AddNew();
            enableFieldsAndDisableActions(true);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (!isValidField())
            {
                txtNome.Focus();
                return;
            }

            Fabricante RegFab = new Fabricante();
            RegFab.NomeFantasia = txtNome.Text.Trim();

            if (bInclusao)
            {
                if (RegFab.Salvar() > 0)
                {
                    frmPrincipal.showSuccess("Fabricante adicionado com sucesso!");

                    disableFieldsAndEnableActions();
                    reloadGrid();
                    return;
                }

                frmPrincipal.showError("Erro ao adicionar fabricante. Verifique os dados e tente novamente.");
                return;
            }

            RegFab.IdFabricante = Convert.ToInt16(txtId.Text);

            if (RegFab.Alterar() > 0)
            {
                frmPrincipal.showSuccess("Fabricante alterado com sucesso!");

                disableFieldsAndEnableActions();
                reloadGrid();
                return;
            }

            frmPrincipal.showError("Erro ao alterar fabricante. Verifique os dados e tente novamente.");

        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            openDetailsTab();
            enableFieldsAndDisableActions(false);
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                openDetailsTab();

                if (MessageBox.Show("Confirma exclusão?", "Yer or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    Fabricante RegFab = new Fabricante();
                    RegFab.IdFabricante = Convert.ToInt16(txtId.Text);

                    if (RegFab.Excluir() > 0)
                    {
                        frmPrincipal.showSuccess("Fabricante excluído com sucesso!");
                        reloadGrid();
                        return;
                    }

                    frmPrincipal.showError("Erro ao excluir fabricante!");
                }
            }
            catch (SqlException ex)
            {
                frmPrincipal.showError($"Este fabricante está atribuido a uma ou mais ferramentas. Delete primeiro a(s) ferramenta(s) e tente novamente.");
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnFabricante.CancelEdit();
            disableFieldsAndEnableActions();
            tbFabricante.SelectTab(0);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
