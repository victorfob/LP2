﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace PFerramenta0030482423040
{
    internal class Categoria
    {
        public int IdCategoria { get; set; }
        public string Descricao { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daCategoria;
            DataTable dtCategoria = new DataTable();
            try
            {
                daCategoria = new SqlDataAdapter("SELECT * FROM CATEGORIA", frmPrincipal.conexao);
                daCategoria.Fill(dtCategoria);
                daCategoria.FillSchema(dtCategoria, SchemaType.Source);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtCategoria;
        }

        public int Salvar()
        {
            int retorno = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO CATEGORIA VALUES (@descricao)", frmPrincipal.conexao);
                //cmd.Parameters.Add(new SqlParameter("@descricao", SqlDbType.VarChar));
                //cmd.Parameters["@descricao"].Value = Descricao;
                cmd.Parameters.AddWithValue("@descricao", Descricao);
                retorno = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retorno;
        }

        public int Alterar()
        {
            int retorno = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE CATEGORIA SET descricao = @descricao WHERE id = @idcategoria", frmPrincipal.conexao);
                cmd.Parameters.AddWithValue("@descricao", Descricao);
                cmd.Parameters.AddWithValue("@idcategoria", IdCategoria);
                retorno = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retorno;
        }

        public int Excluir()
        {
            int retorno = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM CATEGORIA WHERE id = @idcategoria", frmPrincipal.conexao);
                cmd.Parameters.AddWithValue("@idcategoria", IdCategoria);
                retorno = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retorno;
        }
    }
}
