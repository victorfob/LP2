﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace PFerramenta0030482423040
{
    internal class Ferramenta
    {
        public int IdFerramenta { get; set; }
        public string Nome { get; set; }
        public char Distribuicao { get; set; }
        public DateTime DtCadastro { get; set; }
        public string SiteOficial { get; set; }
        public int IdCategoria { get; set; }
        public int IdFabricante { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daFerramenta;
            DataTable dtFerramenta = new DataTable();
            try
            {
                daFerramenta = new SqlDataAdapter("SELECT * FROM FERRAMENTA", frmPrincipal.conexao);
                daFerramenta.Fill(dtFerramenta);
                daFerramenta.FillSchema(dtFerramenta, SchemaType.Source);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtFerramenta;
        }

        public int Salvar()
        {
            int retorno = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO FERRAMENTA VALUES (@nome, @distribuicao, @dtCadastro, @siteOficial, @idCategoria, @idFabricante)", frmPrincipal.conexao);
                cmd.Parameters.AddWithValue("@nome", Nome);
                cmd.Parameters.AddWithValue("@distribuicao", Distribuicao);
                cmd.Parameters.AddWithValue("@dtCadastro", DtCadastro);
                cmd.Parameters.AddWithValue("@siteOficial", SiteOficial);
                cmd.Parameters.AddWithValue("@idCategoria", IdCategoria);
                cmd.Parameters.AddWithValue("@idFabricante", IdFabricante);
                retorno = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retorno;
        }

        public int Alterar()
        {
            int retorno = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE FERRAMENTA SET nome = @nome, distribuicao = @distribuicao, dtCadastro = @dtCadastro, siteOficial = @siteOficial, idCategoria = @idCategoria, idFabricante = @idFabricante WHERE id = @idFerramenta", frmPrincipal.conexao);
                cmd.Parameters.AddWithValue("@nome", Nome);
                cmd.Parameters.AddWithValue("@distribuicao", Distribuicao);
                cmd.Parameters.AddWithValue("@dtCadastro", DtCadastro);
                cmd.Parameters.AddWithValue("@siteOficial", SiteOficial);
                cmd.Parameters.AddWithValue("@idCategoria", IdCategoria);
                cmd.Parameters.AddWithValue("@idFabricante", IdFabricante);
                cmd.Parameters.AddWithValue("@idFerramenta", IdFerramenta);
                retorno = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retorno;
        }

        public int Excluir()
        {
            int retorno = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM FERRAMENTA WHERE id = @idFerramenta", frmPrincipal.conexao);
                cmd.Parameters.AddWithValue("@idFerramenta", IdFerramenta);
                retorno = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retorno;
        }
    }
}
