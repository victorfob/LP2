﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace PFerramenta0030482423040
{
    internal class Fabricante
    {
        public int IdFabricante { get; set; }
        public string NomeFantasia { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daFabricante;
            DataTable dtFabricante = new DataTable();
            try
            {
                daFabricante = new SqlDataAdapter("SELECT * FROM FABRICANTE", frmPrincipal.conexao);
                daFabricante.Fill(dtFabricante);
                daFabricante.FillSchema(dtFabricante, SchemaType.Source);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtFabricante;
        }

        public int Salvar()
        {
            int retorno = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO FABRICANTE VALUES (@nomeFantasia)", frmPrincipal.conexao);
                cmd.Parameters.AddWithValue("@nomeFantasia", NomeFantasia);
                retorno = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retorno;
        }

        public int Alterar()
        {
            int retorno = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE FABRICANTE SET nomeFantasia = @nomeFantasia WHERE id = @idfabricante", frmPrincipal.conexao);
                cmd.Parameters.AddWithValue("@nomeFantasia", NomeFantasia);
                cmd.Parameters.AddWithValue("@idfabricante", IdFabricante);
                retorno = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retorno;
        }

        public int Excluir()
        {
            int retorno = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM FABRICANTE WHERE id = @idfabricante", frmPrincipal.conexao);
                cmd.Parameters.AddWithValue("@idfabricante", IdFabricante);
                retorno = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retorno;
        }
    }
}
