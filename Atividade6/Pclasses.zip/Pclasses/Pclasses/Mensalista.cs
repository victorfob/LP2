﻿using System.Windows.Forms;

namespace Pclasses
{
    internal class Mensalista : Empregado
    {
        public static string Empresa = "Irmãos Silva Ltda.";
        public double SalarioMensal { get; set; }

        public Mensalista()
        {
            MessageBox.Show("Construtor da classe Mensalista");
        }

        public Mensalista(int matx, string nomex, string datax, double salx)
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = ParseDate(datax);
            SalarioMensal = salx;
        }

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
    }
}
