﻿using System;
using System.Windows.Forms;

namespace Pclasses
{
    internal class Horista : Empregado
    {
        public double SalarioHora { get; set; }
        public double NumeroHora { get; set; }
        public int DiasFalta { get; set; }

        public Horista()
        {
            MessageBox.Show("Construtor da classe Horista");
        }

        public Horista(int matx, string nomex, string datax, double salx, double horax, int faltasx)
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = ParseDate(datax);
            SalarioHora = salx;
            NumeroHora = horax;
            DiasFalta = faltasx;
        }

        public override double SalarioBruto()
        {
            return SalarioHora * NumeroHora;
        }

        public override int TempoTrabalho()
        {
            TimeSpan tempoTrabalho = DateTime.Today.Subtract(DataEntradaEmpresa);
            return Convert.ToInt32(tempoTrabalho.Days - DiasFalta);
        }
    }
}
