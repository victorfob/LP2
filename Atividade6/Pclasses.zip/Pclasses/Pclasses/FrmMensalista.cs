﻿using System;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void showMessage(Mensalista mensalista)
        {
            MessageBox.Show(
              "Nome= " + mensalista.NomeEmpregado +
              "\nMatricula= " + mensalista.Matricula +
              "\nTempo de Trabalho= " + mensalista.TempoTrabalho() +
              "\nSalario Final= " + mensalista.SalarioBruto().ToString("N2")
          );
        }

        private void btnInstanciar1_Click(object sender, EventArgs e)
        {
            Mensalista mensalista = new Mensalista
            {
                Matricula = Convert.ToInt32(txtMatricula.Text),
                NomeEmpregado = txtNome.Text,
                SalarioMensal = Convert.ToDouble(txtSalario.Text),
            };
            mensalista.DataEntradaEmpresa = mensalista.ParseDate(txtData.Text);

            showMessage(mensalista);
            MessageBox.Show($"Empresa: {Mensalista.Empresa}");
        }

        private void btnInstanciar2_Click(object sender, EventArgs e)
        {
            Mensalista mensalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                txtData.Text,
                Convert.ToDouble(txtSalario.Text)
            );

            showMessage(mensalista);
        }
    }
}
