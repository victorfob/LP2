﻿using System;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void showMessage(Horista horista)
        {
            MessageBox.Show(
               "Nome= " + horista.NomeEmpregado +
               "\nMatricula= " + horista.Matricula +
               "\nTempo de Trabalho= " + horista.TempoTrabalho() +
               "\nSalario Final= " + horista.SalarioBruto().ToString("N2")
           );
        }

        private void btnInstanciar1_Click(object sender, EventArgs e)
        {
            Horista horista = new Horista
            {
                Matricula = Convert.ToInt32(txtMatricula.Text),
                NomeEmpregado = txtNome.Text,
                SalarioHora = Convert.ToDouble(txtSalario.Text),
                NumeroHora = Convert.ToDouble(txtHoras.Text),
                DiasFalta = Convert.ToInt32(txtFalta.Text)
            };
            horista.DataEntradaEmpresa = horista.ParseDate(txtData.Text);

            showMessage(horista);
        }

        private void btnInstanciar2_Click(object sender, EventArgs e)
        {
            Horista horista = new Horista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                txtData.Text,
                Convert.ToDouble(txtSalario.Text),
                Convert.ToDouble(txtHoras.Text),
                Convert.ToInt32(txtFalta.Text)
            );

            showMessage(horista);
        }
    }
}
