﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace Pclasses
{
    abstract internal class Empregado
    {
        private int matricula;
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public Empregado()
        {
            MessageBox.Show("Construtor da classe base Empregado");
        }

        public int Matricula
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        public virtual DateTime ParseDate(string date)
        {
            if (DateTime.TryParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedDate))
                return parsedDate;

            return DateTime.MinValue;
        }

        public virtual int TempoTrabalho()
        {
            TimeSpan tempoTrabalho = DateTime.Today.Subtract(DataEntradaEmpresa);
            return tempoTrabalho.Days;
        }

        public abstract double SalarioBruto();
    }
}
