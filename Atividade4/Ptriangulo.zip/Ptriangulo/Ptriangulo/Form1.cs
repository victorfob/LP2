﻿using System;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class frmTriangulo : Form
    {
        private double valorA, valorB, valorC;

        public frmTriangulo()
        {
            InitializeComponent();
        }

        private void showError(string message)
        {
            MessageBox.Show(message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool isValidNumber(string text)
        {
            if (string.IsNullOrEmpty(text))
                return false;

            return Double.TryParse(text, out double parsedNumber);
        }

        private bool isValidFields()
        {
            if (!isValidNumber(txtValorA.Text))
            {
                showError("Valor do lado A inválido.");
                txtValorA.Focus();
                return false;
            }
            if (!isValidNumber(txtValorB.Text))
            {
                showError("Valor do lado B inválido.");
                txtValorB.Focus();
                return false;
            }
            if (!isValidNumber(txtValorC.Text))
            {
                showError("Valor do lado C inválido.");
                txtValorC.Focus();
                return false;
            }
            return true;
        }

        private bool isTriangle()
        {
            if (valorA <= 0 || valorB <= 0 || valorC <= 0)
            {
                showError("Todos os valores devem ser números positivos.");
                return false;
            }

            // Usando a forma absoluta das regras de triângulo:
            // |B - C| < A < B + C
            // |A - C| < B < A + C
            // |A - B| < C < A + B

            bool ladoAValido = (Math.Abs(valorB - valorC) < valorA) && (valorA < (valorB + valorC));
            bool ladoBValido = (Math.Abs(valorA - valorC) < valorB) && (valorB < (valorA + valorC));
            bool ladoCValido = (Math.Abs(valorA - valorB) < valorC) && (valorC < (valorA + valorB));

            if (!ladoAValido || !ladoBValido || !ladoCValido)
            {
                showError("Os valores informados não formam um triângulo.");
                return false;
            }

            return true;
        }

        private void showType()
        {
            if (valorA == valorB && valorB == valorC)
            {
                txtResultado.Text = "O triângulo é Equilátero.";
                return;
            }
            if (valorA == valorB || valorB == valorC || valorA == valorC)
            {
                txtResultado.Text = "O triângulo é Isósceles.";
                return;
            }
     
            txtResultado.Text = "O triângulo é Escaleno.";
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (txtValorA.Text == "") return;
            if (!Double.TryParse(txtValorA.Text, out valorA))
                showError("Valor do lado A inválido.");
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (txtValorB.Text == "") return;
            if (!Double.TryParse(txtValorB.Text, out valorB))
                showError("Valor do lado B inválido.");
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (txtValorC.Text == "") return;
            if (!Double.TryParse(txtValorC.Text, out valorC))
                showError("Valor do lado C inválido.");
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (!isValidFields() || !isTriangle()) return;

            showType();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
            txtResultado.Clear();

            txtValorA.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
