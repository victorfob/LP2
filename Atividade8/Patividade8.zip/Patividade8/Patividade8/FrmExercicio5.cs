﻿using Microsoft.VisualBasic;
using System;
using System.Linq;
using System.Windows.Forms;

namespace Patividade8
{
    public partial class FrmExercicio5 : Form
    {
        FrmInicio main = new FrmInicio();

        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private bool checkIfIsValid(string resposta)
        {
            string[] respostasValidas = new string[] { "A", "B", "C", "D", "E" };

            return respostasValidas.Contains(resposta);
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            // RA: 0030482423005
            string[,] respostasAlunos = new string[6, 10];
            string[] gabarito = { "A", "B", "C", "D", "E", "D", "C", "B", "A", "B" };

            for (int i = 0; i < respostasAlunos.GetLength(0); i++)
            {
                for (int j = 0; j < respostasAlunos.GetLength(1); j++)
                {
                    respostasAlunos[i, j] = Interaction.InputBox("Digite a " + (j + 1) + "º resposta do aluno " + (i + 1) + ": ", "Entrada de Dados", "").ToUpper();
                    if (!checkIfIsValid(respostasAlunos[i, j]))
                    {
                        main.showError("Resposta inválida. Digite uma letra entre A e E.");
                        j--;
                    }
                    else
                    {
                        string erradoOuCerto = respostasAlunos[i, j] == gabarito[j] ? "acertou" : "errou";
                        string resultado = "Aluno " + (i + 1) + " " + erradoOuCerto + " a questão " + (j + 1) + ", era " + gabarito[j] + " e escolheu " + respostasAlunos[i, j] + "\n";

                        lbResultado.Items.Add(resultado);
                    }
                }
            }
        }
    }
}
