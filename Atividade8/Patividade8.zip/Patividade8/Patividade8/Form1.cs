﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Patividade8
{
    public partial class FrmInicio : Form
    {
        public FrmInicio()
        {
            InitializeComponent();
        }

        public void showMessage(string message)
        {
            MessageBox.Show(message, "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void showError(string message)
        {
            MessageBox.Show(message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] numeros = new int[20];

            for (int i = 0; i < numeros.Length; i++)
            {
                string auxiliar = Interaction.InputBox("Digite o " + (i + 1) + "º número: ", "Entrada de Dados", "");

                if (!int.TryParse(auxiliar, out numeros[i]))
                {
                    showError("Número inválido. Tente novamente.");
                    i--;
                    continue;
                }
            }

            Array.Reverse(numeros);

            string numerosRevertidos = "Lista de números revertidos:\n";
            numerosRevertidos += string.Join("\n", numeros);

            showMessage(numerosRevertidos);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList listaNomes = new ArrayList() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };

            listaNomes.Remove("Otávio");

            showMessage("Lista de nomes:\n" + string.Join("\n", listaNomes.ToArray()));
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {

            double[,] notas = new double[20, 3];
            string resultado = "Média dos alunos:\n";

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                double media = 0;
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    string auxiliar = Interaction.InputBox("Digite a " + (j + 1) + "ª nota do aluno " + (i + 1) + ": ", "Entrada de Dados", "");

                    if (!double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        showError("Nota inválida. Digite uma nota entre 0 e 10.");
                        j--;
                    }
                    else
                        media += notas[i, j];
                }
                media /= notas.GetLength(1);
                resultado += "Aluno " + (i + 1) + ": " + media.ToString("N2") + "\n";
            }

            showMessage(resultado);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            FrmExercicio4 frmExercicio4 = new FrmExercicio4();
            frmExercicio4.ShowDialog();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            FrmExercicio5 frmExercicio5 = new FrmExercicio5();
            frmExercicio5.ShowDialog();
        }
    }
}
