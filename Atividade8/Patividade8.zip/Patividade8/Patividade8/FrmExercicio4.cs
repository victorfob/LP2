﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Patividade8
{
    public partial class FrmExercicio4 : Form
    {
        FrmInicio main = new FrmInicio();
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lbNomes.Items.Clear();
            string[] nomes = new string[10];

            for (int i = 0; i < nomes.Length; i++)
            {
                string nome = Interaction.InputBox("Digite o " + (i + 1) + "º nome: ", "Entrada de Dados", "");

                if (string.IsNullOrEmpty(nome.Replace(" ", "")))
                {
                    main.showError("Nome inválido. Tente novamente.");
                    i--;
                }
                else
                    nomes[i] = $"{i + 1}º nome: {nome} tem {nome.Replace(" ", "").Length} caracteres";
            }

            lbNomes.Items.AddRange(nomes);
        }
    }
}
